package com.example.myapplication.moduel

data class volunter_structure(
  val instCode: String = "",
  val instName: String = "",
  val district: String = "",
  val enrollmentNo: String = "",
  val studentname: String = "",
  val gender: String = "",
  val dateOfBirth: String = "",
  val cast: String = "",
  val branch: String = "",
  val mainSubject: String = "",
  val email: String = "",
  val phoneNo: String = ""
)