plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    alias(libs.plugins.google.gms.google.services)
}

android {namespace = "com.example.myapplication"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.myapplication"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.navigation.fragment.ktx)
    implementation(libs.firebase.database)
    implementation(libs.firebase.storage.ktx)
    implementation(libs.firebase.firestore)
    //implementation(libs.androidx.ui.desktop) // Consider removing if not needed for desktop UI
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    implementation(libs.play.services.maps)

    implementation(libs.gson)
    //implementation("androidx.core:core-ktx:1.8.0") // Redundant, already included in libs.androidx.core.ktx
    implementation(platform(libs.google.firebase.bom)) // Use the Firebase BOM from your libs block
    implementation(libs.firebase.analytics.ktx) // Use the KTX version for Firebase Analytics
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.recyclerview)
    implementation(libs.androidx.cardview)
    //implementation("com.google.android.material:material:1.9.0") // Redundant, already included in libs.material
    implementation(libs.glide)
    implementation(libs.picasso)
    annotationProcessor(libs.compiler)

    implementation(libs.poi)
    implementation(libs.poi.ooxml)

    implementation(libs.androidx.room.runtime)
    annotationProcessor(libs.androidx.room.compiler)
    implementation(libs.androidx.room.ktx)

    //implementation(libs.google.firebase.bom) // Redundant, already included above
    implementation(libs.firebase.firestore.ktx)

    //implementation(platform("com.google.firebase:firebase-bom:32.2.3")) // Redundant, already included above
    implementation(libs.firebase.messaging.ktx)
}